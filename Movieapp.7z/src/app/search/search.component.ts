import { Component, OnInit } from '@angular/core';
import { Data } from '@angular/router';
import { DataService } from '../data.service';
import { FormControl, FormGroup } from '@angular/forms';
import { Movie } from '../Movie';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  movie:Movie[]=[];
  constructor(public service:DataService) { }

  ngOnInit(): void {
  }
  MovieForm = new FormGroup({
   
    genre: new FormControl
  });
  
  onSubmit()
  {
    return this.service.getMoviesByGenre(this.MovieForm.get("genre").value).subscribe((data:any)=>{
      this.movie=data;
    }
    )

  }
}



