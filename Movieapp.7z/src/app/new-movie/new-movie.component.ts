import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { Movie } from '../Movie';
import { DataService } from '../data.service';

@Component({
  selector: 'app-new-movie',
  templateUrl: './new-movie.component.html',
  styleUrls: ['./new-movie.component.css']
})
export class NewMovieComponent implements OnInit {
  array:Movie[]=[];
  postdata:Movie;
  spresp:any=[];
  constructor(public service:DataService) { }

  ngOnInit(): void {
  }
  MovieForm = new FormGroup({
    movieName: new FormControl,
    rating: new FormControl,
    genre: new FormControl
  });
  onSubmit()
  {
    
    this. postdata=new Movie(this.MovieForm.get("movieName").value,this.MovieForm.get("rating").value,this.MovieForm.get("genre").value);
    
    alert("data is added successfully");
    
    this.service.addNewMovie(this.postdata).subscribe(resp=>{
      return this.spresp.push(resp);
    })
    
  }
}



