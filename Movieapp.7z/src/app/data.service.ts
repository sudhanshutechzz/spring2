import { Movie } from './Movie';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DataService {
 url:string = 'http://localhost:8080/movies';
  constructor(private http:HttpClient) { }
  httpOptions={
    headers:new HttpHeaders({'Content-Type':'application/json'})
  }
  getMoviesByGenre(genre: string): Observable<Movie> {
    const getUrl = `${this.url}/${genre}`;
    
    return this.http.get<Movie>(getUrl);
  }
  addNewMovie(newMovie: Movie): Observable<Movie> {
    const postUrl = `${this.url}`;
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };
    return this.http.post<Movie>(postUrl, newMovie, httpOptions);
  }
}
