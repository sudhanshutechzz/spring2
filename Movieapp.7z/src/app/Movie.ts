export class Movie {
    movieName: string;
    rating: number;
    genre: string;
    constructor(name,rating,genre)
    {
      this.movieName=name;
      this.rating=rating;
      this.genre=genre;
    }
  }