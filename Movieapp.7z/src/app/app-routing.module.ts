import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SearchComponent } from './search/search.component';
import { NewMovieComponent } from './new-movie/new-movie.component';


const routes: Routes = [
  {path:'add', component: NewMovieComponent},
{path:'search', component: SearchComponent}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
